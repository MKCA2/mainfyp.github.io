// // Function to update dashboard data
// async function updateData() {
//   try {
//     const response = await fetch('http://localhost:5000/data');
//     console.log('Fetch response status:', response.status);

//     if (!response.ok) {
//       throw new Error('Error loading data');
//     }

//     const data = await response.json();
//     console.log('Retrieved data:', data);

//     const latestEntry = data[data.length - 1]; // Assuming the last entry is the latest data
//     const latestTemperature = parseFloat(latestEntry.temperature);
//     const latestHumidity = parseFloat(latestEntry.humidity);
//     const latestCO2 = parseFloat(latestEntry.CO2);

//     // Check if 'latestTemperature', 'latestHumidity', and 'latestCO2' are valid numbers
//     if (!isNaN(latestTemperature) && !isNaN(latestHumidity) && !isNaN(latestCO2)) {
//       // Update the values in the dashboard HTML
//       document.getElementById('temperature-value').innerText = latestTemperature.toFixed(2) + '°C';
//       document.getElementById('humidity-value').innerText = latestHumidity.toFixed(2) + '%';
//       document.getElementById('co2-value').innerText = latestCO2.toFixed(2);
//     } else {
//       // Display error messages if any of the data is not valid
//       document.getElementById('temperature-value').innerText = 'Temperature data unavailable';
//       document.getElementById('humidity-value').innerText = 'Humidity data unavailable';
//       document.getElementById('co2-value').innerText = 'CO2 data unavailable';
//     }
//   } catch (error) {
//     console.error('Error loading data:', error);
//   }
// }


// // Function to update temperature data
// async function updateTemperature() {
//   try {
//     const response = await fetch('http://localhost:5000/data');
//     console.log('Fetch response status:', response.status);

//     if (!response.ok) {
//       throw new Error('Error loading temperature data');
//     }

//     const data = await response.json();
//     console.log('Retrieved temperature data:', data);

//     const latestTemperature = parseFloat(data.temperature);

//     // Check if 'latestTemperature' is a valid number
//     if (!isNaN(latestTemperature)) {
//       // Update the temperature value in the HTML
//       document.getElementById('temperature-value').innerText = latestTemperature.toFixed(2) + '°C';
//     } else {
//       // Display an error message if 'latestTemperature' is not a valid number
//       document.getElementById('temperature-value').innerText = 'Temperature data unavailable';
//     }
//   } catch (error) {
//     console.error('Error loading temperature data:', error);
//   }
// }

// // Function to update humidity data
// async function updateHumidity() {
//   try {
//     const response = await fetch('http://localhost:5000/data');
//     console.log('Fetch response status:', response.status);

//     if (!response.ok) {
//       throw new Error('Error loading humidity data');
//     }

//     const data = await response.json();
//     console.log('Retrieved humidity data:', data);

//     const latestHumidity = parseFloat(data.humidity);

//     // Check if 'latestHumidity' is a valid number
//     if (!isNaN(latestHumidity)) {
//       // Update the humidity value in the HTML
//       document.getElementById('humidity-value').innerText = latestHumidity.toFixed(2) + '%';
//     } else {
//       // Display an error message if 'latestHumidity' is not a valid number
//       document.getElementById('humidity-value').innerText = 'Humidity data unavailable';
//     }
//   } catch (error) {
//     console.error('Error loading humidity data:', error);
//   }
// }

// // Function to update CO2 data
// async function updateCO2() {
//   try {
//     const response = await fetch('http://localhost:5000/data');
//     console.log('Fetch response status:', response.status);

//     if (!response.ok) {
//       throw new Error('Error loading CO2 data');
//     }

//     const data = await response.json();
//     console.log('Retrieved CO2 data:', data);

//     const latestCO2 = parseFloat(data.CO2);

//     // Check if 'latestCO2' is a valid number
//     if (!isNaN(latestCO2)) {
//       // Update the CO2 value in the HTML
//       document.getElementById('co2-value').innerText = latestCO2.toFixed(2);
//     } else {
//       // Display an error message if 'latestCO2' is not a valid number
//       document.getElementById('co2-value').innerText = 'CO2 data unavailable';
//     }
//   } catch (error) {
//     console.error('Error loading CO2 data:', error);
//   }
// }

// // Determine the current page and call the relevant function
// const currentPage = document.body.id;

// if (currentPage === 'dashboard') {
//   updateData();
//   setInterval(updateData(), 5000);
// } else if (currentPage === 'temperature') {
//   updateTemperature();
//   setInterval(updateTemperature(), 5000);
// } else if (currentPage === 'humidity') {
//   updateHumidity();
//   setInterval(updateHumidity(), 5000);
// } else if (currentPage === 'co2') {
//   updateCO2();
//   setInterval(updateData(), 5000);
// } else {
//   console.error('Unknown page:', currentPage);
// }


// Function to update dashboard data
async function updateData() {
  try {
    const response = await fetch('http://localhost:5000/fullData');
    console.log('Fetch response status:', response.status);

    if (!response.ok) {
      throw new Error('Error loading data');
    }

    const data = await response.json();
    console.log('Retrieved data:', data);

    const latestEntry = data[data.length - 1]; // Assuming the last entry is the latest data
    const latestTemperature = parseFloat(latestEntry.temperature);
    const latestHumidity = parseFloat(latestEntry.humidity);
    const latestCO2 = parseFloat(latestEntry.CO2);

    // Check if 'latestTemperature', 'latestHumidity', and 'latestCO2' are valid numbers
    if (!isNaN(latestTemperature) && !isNaN(latestHumidity) && !isNaN(latestCO2)) {
      // Update the values in the dashboard HTML
      document.getElementById('temperature-value').innerText = latestTemperature.toFixed(2) + '°C';
      document.getElementById('humidity-value').innerText = latestHumidity.toFixed(2) + '%';
      document.getElementById('co2-value').innerText = latestCO2.toFixed(2);
    } else {
      // Display error messages if any of the data is not valid
      document.getElementById('temperature-value').innerText = 'Temperature data unavailable';
      document.getElementById('humidity-value').innerText = 'Humidity data unavailable';
      document.getElementById('co2-value').innerText = 'CO2 data unavailable';
    }
  } catch (error) {
    console.error('Error loading data:', error);
  }
}



// Function to update temperature data
async function updateTemperature() {
  try {
    const response = await fetch('http://localhost:5000/fullData');
    console.log('Fetch response status:', response.status);

    if (!response.ok) {
      throw new Error('Error loading temperature data');
    }

    const data = await response.json();
    console.log('Retrieved temperature data:', data);

    const latestEntry = data[data.length - 1]; // Assuming the last entry is the latest data
    const latestTemperature = parseFloat(latestEntry.temperature);

    // Check if 'latestTemperature' is a valid number
    if (!isNaN(latestTemperature)) {
      // Update the temperature value in the HTML
      document.getElementById('temperature-value').innerText = latestTemperature.toFixed(2) + '°C';
    } else {
      // Display an error message if 'latestTemperature' is not a valid number
      document.getElementById('temperature-value').innerText = 'Temperature data unavailable';
    }
  } catch (error) {
    console.error('Error loading temperature data:', error);
  }
}

// Function to update humidity data
async function updateHumidity() {
  try {
    const response = await fetch('http://localhost:5000/fullData');
    console.log('Fetch response status:', response.status);

    if (!response.ok) {
      throw new Error('Error loading humidity data');
    }

    const data = await response.json();
    console.log('Retrieved humidity data:', data);

    const latestEntry = data[data.length - 1]; // Assuming the last entry is the latest data
    const latestHumidity = parseFloat(latestEntry.humidity);

    // Check if 'latestHumidity' is a valid number
    if (!isNaN(latestHumidity)) {
      // Update the humidity value in the HTML
      document.getElementById('humidity-value').innerText = latestHumidity.toFixed(2) + '%';
    } else {
      // Display an error message if 'latestHumidity' is not a valid number
      document.getElementById('humidity-value').innerText = 'Humidity data unavailable';
    }
  } catch (error) {
    console.error('Error loading humidity data:', error);
  }
}

// Function to update CO2 data
async function updateCO2() {
  try {
    const response = await fetch('http://localhost:5000/fullData');
    console.log('Fetch response status:', response.status);

    if (!response.ok) {
      throw new Error('Error loading CO2 data');
    }

    const data = await response.json();
    console.log('Retrieved CO2 data:', data);

    const latestEntry = data[data.length - 1]; // Assuming the last entry is the latest data
    const latestCO2 = parseFloat(latestEntry.CO2);

    // Check if 'latestCO2' is a valid number
    if (!isNaN(latestCO2)) {
      // Update the CO2 value in the HTML
      document.getElementById('co2-value').innerText = latestCO2.toFixed(2);
    } else {
      // Display an error message if 'latestCO2' is not a valid number
      document.getElementById('co2-value').innerText = 'CO2 data unavailable';
    }
  } catch (error) {
    console.error('Error loading CO2 data:', error);
  }
}





const currentPage = document.body.id;
console.log(currentPage)
if (currentPage === 'dashboard') {
  updateData();
  setInterval(updateData, 5000);
} else if (currentPage === 'temperature') {
  updateTemperature();
  setInterval(updateTemperature, 5000);
} else if (currentPage === 'humidity') {
  updateHumidity();
  setInterval(updateHumidity, 5000);
} else if (currentPage === 'co2') {
  updateCO2();
  setInterval(updateCO2, 5000);
} else {
  console.error('Unknown page:', currentPage);
}