window.addEventListener('DOMContentLoaded', async event => {
    console.log('DOMContentLoaded event fired'); // Check if the event is firing

    const table = $('#datatablesSimple').DataTable({
        columns: [
            { title: 'ID', data: 'ID' },
                        { title: 'Date and Time', data: 'date' },
                        { title: 'Temperature', data: 'temperature' },
                        { title: 'Humidity', data: 'humidity' },
                        { title: 'CO2', data: 'CO2' }
        ],
        paging: true,
        pageLength: 10,
        lengthMenu: [5, 10, 15, 20],
        ordering: true,
        searching: true,
        responsive: true,
        buttons: [
            'copy',
            'excel',
            'pdf',
            'print'
        ],
        // Specify any additional options here
    });

    async function updateTable() {
        try {
            const response = await fetch('http://localhost:5000/fullData');
            console.log('Fetch response status:', response.status); // Check fetch response status

            if (!response.ok) {
                throw new Error('Error loading data');
            }

            const data = await response.json();
            console.log('Retrieved data:', data); // Output the retrieved data to the console

            table.clear().rows.add(data).draw();
        } catch (error) {
            console.error('Error loading data:', error);
        }
    }

    // Call updateTable initially
    updateTable();

    // Call updateTable every 5 seconds
    setInterval(updateTable, 5000);
});





// // display.js

// window.addEventListener('DOMContentLoaded', async event => {
//     console.log('DOMContentLoaded event fired'); // Check if the event is firing

//     const table = $('#datatablesSimple').DataTable({
//         columns: [
//             { title: 'ID', data: 'ID' },
//             { title: 'Date and Time', data: 'date' },
//             { title: 'Temperature', data: 'temperature' },
//             { title: 'Humidity', data: 'humidity' },
//             { title: 'CO2', data: 'CO2' }
//         ],
//         paging: true,
//         pageLength: 10,
//         lengthMenu: [5, 10, 15, 20],
//         ordering: true,
//         searching: true,
//         responsive: true,
//         buttons: [
//             'copy',
//             'excel',
//             'pdf',
//             'print'
//         ],
//         // Specify any additional options here
//     });

    
//     // Connect to the WebSocket server
//     let ws = new WebSocket('ws://localhost:8765');

//     // Event handler for WebSocket connection open
//     ws.onopen = () => {
//         console.log('WebSocket connection established');
//     };

//     // Event handler for WebSocket message received
//     ws.onmessage = event => {
//         try {
//             const data = JSON.parse(event.data);
//             if (Array.isArray(data)) {
//                 console.log('Initial data received:', data);
//                 // Clear the DataTable and add the initial data
//                 table.clear().rows.add(data).draw();
//             } else {
//                 console.log('New document received:', data);
//                 // Add the new data and redraw the DataTable
//                 table.row.add(data).draw();
//             }
//         } catch (error) {
//             console.error('Error parsing WebSocket message:', error);
//         }
//     };

//     // Event handler for WebSocket connection close
//     ws.onclose = event => {
//         console.log('WebSocket connection closed');
//         // Reconnect after a delay (e.g., 5 seconds)
//         setTimeout(() => {
//             console.log('Reconnecting...');
//             ws = new WebSocket('ws://localhost:8765');
//         }, 5000);
//     };
// });
