document.addEventListener('DOMContentLoaded', function() {
    // Get the form element
    const form = document.getElementById('settings-form');

    // Add an event listener to the form on submission
    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the default form submission

        // Get the selected alert options
        const alertTelegram = document.getElementById('alert-telegram').checked ? 1: 0;
        const alertEmail = document.getElementById('alert-email').checked ? 1: 0;

        // Get the entered thresholds
        const temperatureThreshold = parseFloat(document.getElementById('temperature-threshold').value);
        const co2Threshold = parseFloat(document.getElementById('co2-threshold').value);

        // Create a JSON object to hold the form data
        const formData = {
            'alert-telegram': alertTelegram,
            'alert-email': alertEmail,
            'temperature-threshold': temperatureThreshold,
            'co2-threshold': co2Threshold,
        };

        // Send the form data to the server using fetch or XMLHttpRequest
        fetch('http://localhost:5000/save_settings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        })
        .then(response => response.json())
        .then(data => {
            console.log(data.message); // Log the response from the server
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });
});