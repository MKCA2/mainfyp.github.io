# email_noti.py
import smtplib
from flask import Blueprint
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from flask import Blueprint, request
from flask import Flask, render_template
import datetime
import time

email_app = Blueprint('email_app', __name__)

emails_sent_this_week = 0
telegram_sent_this_week = 0
# Function to send an email notification

def send_email_notification(subject, message):
    # Email details
    sender_email = 'calvinchan0513@gmail.com'  # Replace with your email address
    sender_password = 'kjskulleqdnvzufg[Changed]'  # Replace with your email password
    receiver_email = 'helas202dd@gmail.com'  # Replace with the actual email address of the user

    # Email content
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = subject

    # Attach the email message
    msg.attach(MIMEText(message, 'plain'))

    try:
        # Connect to the SMTP server (Gmail server in this case) using SSL/TLS
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)

        # Log in to your email account
        server.login(sender_email, sender_password)

        # Send the email
        server.sendmail(sender_email, receiver_email, msg.as_string())
        

        # Disconnect from the server
        server.quit()
        global emails_sent_this_week
        emails_sent_this_week += 1
        return "Email sent successfully"  # Return a success message

    except Exception as e:
        print("Failed to send email. Error:", str(e))
        return "Failed to send email"  # Return an error message
        



counters_co2 = 0
counters_temperature = 0

co2_alert_sent = False
temperature_alert_sent = False


normal_alert = False
normal_counter = 0

previous_co2_above_threshold = False
previous_temperature_above_threshold = False

@ email_app.route('/handle_occurrence_counters_and_send_email', methods=['POST'])
def handle_occurrence_counters_and_send_email():
    global counters_co2
    global counters_temperature
    global co2_alert_sent
    global temperature_alert_sent
    global previous_co2_above_threshold
    global previous_temperature_above_threshold


    data = request.form
    temperature = float(data.get('temperature', 0))
    co2 = float(data.get('co2', 0))
    co2_threshold = float(data.get('threshold_co2', 0))
    temperature_threshold = float(data.get('threshold_temperature', 0))


    # Check co2 level
    if co2 >= co2_threshold:
        counters_co2 += 1


        if counters_co2 == 5 and not co2_alert_sent and not temperature_alert_sent:
            co2_alert_sent = True
            subject = "High CO2 Alert!"
            message = "The CO2 level has consistently been above the threshold for a while"
            response = send_email_notification(subject, message)
            print(response)  # Print the response (for debugging purposes)
            counters_co2 = 0
            co2_alert_sent = False

        elif co2_alert_sent and not temperature_alert_sent:
            print(f"current co2 counter:  {counters_co2}")
            counters_co2 = 0
            co2_alert_sent = False
    else:
        counters_co2 = 0


    if temperature >= temperature_threshold:
        counters_temperature += 1


        if counters_temperature == 5 and not temperature_alert_sent and not co2_alert_sent:
            temperature_alert_sent = True
            subject = "High Temperature Alert!"
            message = "The temperature has consistently been above the threshold for a while"
            response = send_email_notification(subject, message)
            print(response)  # Print the response (for debugging purposes)
            counters_temperature = 0
            temperature_alert_sent = False

        elif temperature_alert_sent:
            counters_temperature = 0
            temperature_alert_sent = False
    else:
        counters_co2 = 0


    print(f"Current CO2 counter: {counters_co2}")
    print(f"Current Temperature counter: {counters_temperature}")

    global telegram_sent_this_week
    telegram_sent_this_week += 1

    return "Done"  # Return a response at the end of the function

def reset_weekly_counters():
    global emails_sent_this_week
    global telegram_sent_this_week

    # Check if a new week has started (e.g., every Monday at 00:00)
    now = datetime.datetime.now()
    if now.weekday() == 0 and now.hour == 0 and now.minute == 0:
        emails_sent_this_week = 0
        telegram_sent_this_week = 0

# Periodically reset the counters (e.g., every hour)
# while True:
#     reset_weekly_counters()
#     # Sleep for an hour before resetting again
#     time.sleep(3600)  # 3600 seconds = 1 hour

# Route to display the analytics.html template with the data
@ email_app.route('/analytics')
def display_analytics():
    # Prepare the data to pass to the template
    data = {
        'emails_sent_this_week': emails_sent_this_week,
        'telegram_sent_this_week': telegram_sent_this_week
    }

    # Render the analytics.html template with the data
    return render_template('analytics.html', **data)
# Create a Flask app instance
app = Flask(__name__)

# Register the email_app Blueprint with the app instance
app.register_blueprint(email_app)

# Run the Flask application
if __name__ == '__main__':
    app.run(debug=True)



    


