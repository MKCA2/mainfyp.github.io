# fetch.py

from flask import Flask, jsonify, Blueprint
import mysql.connector

fetch = Blueprint('fetch', __name__)

# Replace with your database credentials
host = 'localhost'
username = 'root'
password = ''
database = 'fyp'

def get_database_connection():
    return mysql.connector.connect(host=host, user=username, password=password, database=database)

@fetch.route('/data', methods=['GET'])
def get_data():
    try:
        connection = get_database_connection()
        cursor = connection.cursor(dictionary=True)
        query = "SELECT * FROM data ORDER BY date DESC LIMIT 10"

        cursor.execute(query)
        data = cursor.fetchall()

        # Close the database connection
        cursor.close()
        connection.close()
        
        # Return the JSON response
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)})
    
@fetch.route('/fullData', methods=['GET'])
def get_full_data():
    try:
        connection = get_database_connection()
        cursor = connection.cursor(dictionary=True)
        query = "SELECT * FROM data"
        cursor.execute(query)
        data = cursor.fetchall()

        # Close the database connection
        cursor.close()
        connection.close()
        
        # Return the JSON response
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)})
    
@fetch.route('/getAnalytics', methods=['GET'])
def get_data_analytics():
    try:
        connection = get_database_connection()
        cursor = connection.cursor(dictionary=True)
        query = "SELECT * FROM data ORDER BY id DESC LIMIT 1"
        cursor.execute(query)
        # cursor.execute(query2)
        data = cursor.fetchone()

        # Close the database connection
        cursor.close()
        connection.close()
        
        # Return the JSON response
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)})

