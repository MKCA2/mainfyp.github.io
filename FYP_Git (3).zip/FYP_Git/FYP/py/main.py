# main.py
from flask import Flask
import threading
from email_noti import email_app
from sendData import send_data_app  
from tele import tele_app  
from flask_cors import CORS 
from getData import fetch
# from getData import start_watch_thread
from mongo_to_php import start_threading
from getThreshold import fetchThreshold


app = Flask(__name__)

CORS(app)


app.register_blueprint(email_app)
app.register_blueprint(send_data_app)
app.register_blueprint(tele_app)
app.register_blueprint(fetch)
app.register_blueprint(fetchThreshold)



if __name__ == '__main__':
    
    try:
        thread = threading.Thread(target=start_threading)
        thread.daemon = True
        thread.start()
        app.run(host='0.0.0.0', port=5000)
    except KeyboardInterrupt:
        pass  # Ignore the KeyboardInterrupt

    
