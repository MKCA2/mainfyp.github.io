import asyncio
import requests
from flask import Blueprint, request, jsonify

###################################################################################

TOKEN = '6461103346:AAE61CyrfT9WciOL2soA50myW4mGhrQJaQ4[Changed]'
BOT_USERNAME = 'FYP_telealert_bot[Changed]'
CHAT_ID = '1713499634[Changed]'

counters_co2 = 0
counters_temperature = 0

co2_alert_sent = False
temperature_alert_sent = False

previous_co2_above_threshold = False
previous_temperature_above_threshold = False

###################################################################################

tele_app = Blueprint('tele_app', __name__)

async def send_alert(message: str, chat_id: str, token: str):
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": message
    }
    response = requests.post(url, json=payload)
    if response.status_code != 200:
        print(f"Failed to send alert: {response.text}")
    else:
        print("Alert sent successfully") 








@tele_app.route('/check_threshold', methods=['POST'])
def check_threshold():
    global counters_co2
    global counters_temperature
    global co2_alert_sent
    global temperature_alert_sent
    global previous_co2_above_threshold
    global previous_temperature_above_threshold

    data = request.form
    temperature = float(data.get('temperature', 0))
    co2 = float(data.get('co2', 0))
    co2_threshold = float(data.get('threshold_co2', 0))
    temperature_threshold = float(data.get('threshold_temperature', 0))
    

    
    alert_message = ''

    # Check CO2 level
    if co2 >= co2_threshold:
        counters_co2 += 1
        print(f"Current CO2 counter: {counters_co2}")

        if counters_co2 == 5 and not co2_alert_sent and not temperature_alert_sent:
            co2_alert_sent = True
            alert_message = "High CO2 Alert!\n\nThe CO2 level has consistently been above the threshold for a while."
            asyncio.run(send_alert(alert_message, CHAT_ID, TOKEN))
            counters_co2 = 0
            co2_alert_sent = False

        elif co2_alert_sent and not temperature_alert_sent:
            print(f"Current CO2 counter: {counters_co2}")
            counters_co2 = 0
            co2_alert_sent = False

        # Set the previous_co2_above_threshold flag
        previous_co2_above_threshold = True
    else:
        counters_co2 = 0
        if previous_co2_above_threshold:
            # If the previous reading was above the threshold and the current reading is below the threshold,
            # send the alert indicating that the CO2 level has returned to normal.
            alert_message = "CO2 Level Normalized!\n\nThe CO2 level has decreased below the threshold."
            asyncio.run(send_alert(alert_message, CHAT_ID, TOKEN))
            previous_co2_above_threshold = False

    # Check temperature level
    if temperature >= temperature_threshold:
        counters_temperature += 1
        print(f"Current temperature counter: {counters_temperature}")

        if counters_temperature == 5 and not temperature_alert_sent and not co2_alert_sent:
            temperature_alert_sent = True
            alert_message = "High Temperature Alert!\n\nThe temperature has consistently been above the threshold for a while."
            asyncio.run(send_alert(alert_message, CHAT_ID, TOKEN))
            counters_temperature = 0
            temperature_alert_sent = False

        elif temperature_alert_sent:
            counters_temperature = 0
            temperature_alert_sent = False

        # Set the previous_temperature_above_threshold flag
        previous_temperature_above_threshold = True
    else:
        counters_temperature = 0
        if previous_temperature_above_threshold:
            # If the previous reading was above the threshold and the current reading is below the threshold,
            # send the alert indicating that the temperature has returned to normal.
            alert_message = "Temperature Normalized!\n\nThe temperature has decreased below the threshold."
            asyncio.run(send_alert(alert_message, CHAT_ID, TOKEN))
            previous_temperature_above_threshold = False

    print(f"Current CO2 counter: {counters_co2}")
    print(f"Current Temperature counter: {counters_temperature}")

    return 'Threshold checked'
