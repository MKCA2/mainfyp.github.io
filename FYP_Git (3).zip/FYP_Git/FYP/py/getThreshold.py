from flask import Flask, jsonify, Blueprint
import mysql.connector

fetchThreshold = Blueprint('fetchThreshold', __name__)

# Replace with your database credentials
host = 'localhost'
username = 'root'
password = ''   
database = 'fyp'

def get_database_connection():
    return mysql.connector.connect(host=host, user=username, password=password, database=database)

@fetchThreshold.route('/threshold', methods=['GET'])
def get_threshold_data():
    try:
        connection = get_database_connection()
        cursor = connection.cursor(dictionary=True) 
        query = "SELECT * FROM settingsdata ORDER BY id DESC LIMIT 1"
        cursor.execute(query)
        data = cursor.fetchone()  # Use fetchone() to get a single record

        # Close the database connection
        cursor.close()
        connection.close()
        
        # Return the JSON response
        return jsonify(data) if data else jsonify({'error': 'No data found'})
    except Exception as e:
        return jsonify({'error': str(e)})


















# @fetchThreshold.route('/threshold', methods=['GET'])
# def get_threshold_data():
#     try:
#         connection = get_database_connection()
#         cursor = connection.cursor(dictionary=True) 
#         query = "SELECT * FROM settingsdata ORDER BY id DESC LIMIT 1"  # Retrieve the latest record
#         cursor.execute(query)
#         # query = "SELECT * FROM settingsdata"
#         # # query2 = "SELECT * FROM settingsdata ORDER BY date DESC LIMIT 10"
#         # cursor.execute(query)
#         # cursor.execute(query2)
#         data = cursor.fetchall()

#         # Close the database connection
#         cursor.close()
#         connection.close()
        
#         # Return the JSON response
#         return jsonify(data)
#     except Exception as e:
#         return jsonify({'error': str(e)})
    
    

# @fetch.route('/data', methods=['GET'])
# def get_data():
#     try:
#         connection = get_database_connection()
#         cursor = connection.cursor(dictionary=True)
#         query = "SELECT * FROM settingsdata"
#         cursor.execute(query)
#         data = cursor.fetchall()

#         # Close the database connection
#         cursor.close()
#         connection.close()
        
#         # Return the JSON response
#         return jsonify(data)
#     except Exception as e:
#         return jsonify({'error': str(e)})